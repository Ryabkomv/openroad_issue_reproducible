#!/bin/sh
dir=$(cd -P -- "$(dirname -- "$0")" && pwd -P)
cd $dir;
export GLB_RT_OVERFLOW_ITERS='50';
export GLB_RESIZER_SETUP_MAX_BUFFER_PERCENT='50';
export GLB_OPTIMIZE_MIRRORING='1';
export RT_MAX_LAYER='met5';
export OR_SCRIPT_3='openlane/scripts/openroad/set_routing_layers.tcl';
export STA_LEF='./tmp/merged.nom.lef';
export GLB_RESIZER_HOLD_SLACK_MARGIN='0.2';
export OR_SCRIPT_1='./tmp/cts/13-resizer_timing.sdc';
export OR_SCRIPT_4='openlane/scripts/openroad/layer_adjustments.tcl';
export STA_PRE_CTS='1';
export CURRENT_DEF='./in.def';
export TECH_METAL_LAYERS='li1  met1  met2  met3  met4  met5';
export CURRENT_SDC='./tmp/cts/13-resizer_timing.sdc';
export OR_SCRIPT_5='openlane/scripts/openroad/set_rc.tcl';
export GLB_RESIZER_SETUP_SLACK_MARGIN='0.05';
export OR_SCRIPT_6='openlane/scripts/openroad/sta.tcl';
export DESIGN_NAME='ExampleRocketSystem';
export CURRENT_NETLIST='./results/cts/ExampleRocketSystem.resized.v';
export RT_MIN_LAYER='met1';
export RUN_STANDALONE='1';
export GLB_RT_ALLOW_CONGESTION='0';
export GLB_RESIZER_HOLD_MAX_BUFFER_PERCENT='50';
export CELL_PAD_EXCLUDE='sky130_fd_sc_hd__tap* sky130_fd_sc_hd__decap* sky130_ef_sc_hd__decap* sky130_fd_sc_hd__fill*';
export OR_SCRIPT_0='openlane/scripts/openroad/resizer_routing_timing.tcl';
export CELL_PAD='2';
export OR_SCRIPT_2='./tmp/routing/15-resizer_timing.sdc';
export LIB_SYNTH_COMPLETE='pdk/sky130A/libs.ref/sky130_fd_sc_hd/lib/sky130_fd_sc_hd__tt_025C_1v80.lib';
export MERGED_LEF_UNPADDED='./tmp/merged.unpadded.nom.lef';
export GLB_RT_LAYER_ADJUSTMENTS='0.99,0,0,0,0,0';
export CLOCK_PORT='clock';
export DONT_USE_CELLS='sky130_fd_sc_hd__a2111oi_0 sky130_fd_sc_hd__a21boi_0 sky130_fd_sc_hd__and2_0 sky130_fd_sc_hd__buf_16 sky130_fd_sc_hd__clkdlybuf4s15_1 sky130_fd_sc_hd__clkdlybuf4s18_1 sky130_fd_sc_hd__fa_4 sky130_fd_sc_hd__lpflow_bleeder_1 sky130_fd_sc_hd__lpflow_clkbufkapwr_1 sky130_fd_sc_hd__lpflow_clkbufkapwr_16 sky130_fd_sc_hd__lpflow_clkbufkapwr_2 sky130_fd_sc_hd__lpflow_clkbufkapwr_4 sky130_fd_sc_hd__lpflow_clkbufkapwr_8 sky130_fd_sc_hd__lpflow_clkinvkapwr_1 sky130_fd_sc_hd__lpflow_clkinvkapwr_16 sky130_fd_sc_hd__lpflow_clkinvkapwr_2 sky130_fd_sc_hd__lpflow_clkinvkapwr_4 sky130_fd_sc_hd__lpflow_clkinvkapwr_8 sky130_fd_sc_hd__lpflow_decapkapwr_12 sky130_fd_sc_hd__lpflow_decapkapwr_3 sky130_fd_sc_hd__lpflow_decapkapwr_4 sky130_fd_sc_hd__lpflow_decapkapwr_6 sky130_fd_sc_hd__lpflow_decapkapwr_8 sky130_fd_sc_hd__lpflow_inputiso0n_1 sky130_fd_sc_hd__lpflow_inputiso0p_1 sky130_fd_sc_hd__lpflow_inputiso1n_1 sky130_fd_sc_hd__lpflow_inputiso1p_1 sky130_fd_sc_hd__lpflow_inputisolatch_1 sky130_fd_sc_hd__lpflow_isobufsrc_1 sky130_fd_sc_hd__lpflow_isobufsrc_16 sky130_fd_sc_hd__lpflow_isobufsrc_2 sky130_fd_sc_hd__lpflow_isobufsrc_4 sky130_fd_sc_hd__lpflow_isobufsrc_8 sky130_fd_sc_hd__lpflow_isobufsrckapwr_16 sky130_fd_sc_hd__lpflow_lsbuf_lh_hl_isowell_tap_1 sky130_fd_sc_hd__lpflow_lsbuf_lh_hl_isowell_tap_2 sky130_fd_sc_hd__lpflow_lsbuf_lh_hl_isowell_tap_4 sky130_fd_sc_hd__lpflow_lsbuf_lh_isowell_4 sky130_fd_sc_hd__lpflow_lsbuf_lh_isowell_tap_1 sky130_fd_sc_hd__lpflow_lsbuf_lh_isowell_tap_2 sky130_fd_sc_hd__lpflow_lsbuf_lh_isowell_tap_4 sky130_fd_sc_hd__mux4_4 sky130_fd_sc_hd__o21ai_0 sky130_fd_sc_hd__o311ai_0 sky130_fd_sc_hd__or2_0 sky130_fd_sc_hd__probe_p_8 sky130_fd_sc_hd__probec_p_8 sky130_fd_sc_hd__xor3_1 sky130_fd_sc_hd__xor3_2 sky130_fd_sc_hd__xor3_4 sky130_fd_sc_hd__xnor3_1 sky130_fd_sc_hd__xnor3_2 sky130_fd_sc_hd__xnor3_4 ';
export LIB_RESIZER_OPT='./tmp/synthesis/resizer_sky130_fd_sc_hd__tt_025C_1v80.lib';
export SCRIPTS_DIR='openlane/scripts';
export WIRE_RC_LAYER='met1';
export GLB_RESIZER_ALLOW_SETUP_VIOS='0';
export SAVE_SDC='./tmp/routing/15-resizer_timing.sdc';
export SAVE_DEF='./out.def';
export GLB_RT_ADJUSTMENT='0.25';
OPENROAD_BIN=${OPENROAD_BIN:-openroad}
$OPENROAD_BIN -exit $OR_SCRIPT_0
    