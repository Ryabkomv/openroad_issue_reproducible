#!/bin/sh
dir=$(cd -P -- "$(dirname -- "$0")" && pwd -P)
cd $dir;
export STA_LEF='./tmp/merged.nom.lef';
export RT_MAX_LAYER='met5';
export PACKAGED_SCRIPT_2='openlane/scripts/openroad/set_rc.tcl';
export GLB_RT_MACRO_EXTENSION='0';
export PL_BASIC_PLACEMENT='0';
export CURRENT_DEF='./in.def';
export CELL_PAD_EXCLUDE='sky130_fd_sc_hd__tap* sky130_fd_sc_hd__decap* sky130_ef_sc_hd__decap* sky130_fd_sc_hd__fill*';
export PACKAGED_SCRIPT_4='openlane/scripts/openroad/layer_adjustments.tcl';
export PL_ESTIMATE_PARASITICS='1';
export SAVE_DEF='./out.def';
export GLB_RT_ADJUSTMENT='0.15';
export PACKAGED_SCRIPT_1='./tmp/floorplan/3-initial_fp.sdc';
export RT_MIN_LAYER='met1';
export PL_TIME_DRIVEN='1';
export LIB_SYNTH_COMPLETE='pdk/sky130A/libs.ref/sky130_fd_sc_hd/lib/sky130_fd_sc_hd__tt_025C_1v80.lib';
export PL_ROUTABILITY_DRIVEN='1';
export CELL_PAD='1';
export PACKAGED_SCRIPT_0='openlane/scripts/openroad/replace.tcl';
export CURRENT_SDC='./tmp/floorplan/3-initial_fp.sdc';
export WIRE_RC_LAYER='met1';
export TECH_METAL_LAYERS='li1 met1 met2 met3 met4 met5';
export GLB_RT_LAYER_ADJUSTMENTS='0.99,0,0,0,0,0';
export PL_SKIP_INITIAL_PLACEMENT='0';
export CLOCK_PORT='clock';
export PACKAGED_SCRIPT_5='openlane/scripts/openroad/sta.tcl';
export STA_PRE_CTS='1';
export SCRIPTS_DIR='openlane/scripts';
export MERGED_LEF_UNPADDED='./tmp/merged.unpadded.nom.lef';
export PL_TARGET_DENSITY='0.5';
export RUN_STANDALONE='1';
export PACKAGED_SCRIPT_3='openlane/scripts/openroad/set_routing_layers.tcl';
export DESIGN_NAME='ExampleRocketSystem';
export CURRENT_NETLIST='./results/synthesis/ExampleRocketSystem.v';
TOOL_BIN=${TOOL_BIN:-openroad}
$TOOL_BIN -exit $PACKAGED_SCRIPT_0
